This version of scheck incorporates some changes into scheck 1.2 that is available for download from Timo Latvala's website. The changes were made so that scheck could be compiled on newer gcc compilers. The code compiles fine with gcc 4.4.5. However, please note that I am not the original developer or the current maintainer of this code. For further details, please refer to README.html.

Amit Bhatia, Computer Science Department, Rice University, 
April 7, 2011.
